const modal = document.getElementById("customerModal");

function openModal() {
    modal.style.display = "flex";
}

function closeModal() {
    modal.style.display = "none";
}

window.addEventListener("click", function(event) {
    if (event.target === modal) {
        closeModal();
    }
});

function addCustomer(event) {

    event.preventDefault();

    const name = document.getElementById("customerName").value;

    alert(name + " has been added successfully!");

    event.target.reset();

    closeModal();
}